library(survey)
## check many permutations of fpc specification
example(fpc)

